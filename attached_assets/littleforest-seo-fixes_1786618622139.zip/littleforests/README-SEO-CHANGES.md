# SEO / crawlability fixes — what changed and what's left

## How to apply
Copy these files into your project at the same paths (overwrite existing
ones). Then:

```
npm install          # installs react-helmet-async + puppeteer (new deps)
npm run build         # runs vite build, then esbuild, then the new
                       # postbuild prerender step automatically
```

Test locally before deploying: after `npm run build`, check
`dist/public/about/index.html` and `dist/public/products/<some-id>/index.html`
— they should contain fully rendered content (headings, prices, text), not
an empty `<div id="root">`. If a product/API isn't reachable, the prerender
step logs which route failed and continues (it doesn't fail your build).

## What I changed and why

1. **`vercel.json`** — `/sitemap.xml` and `/llms.txt` were being swallowed by
   the catch-all rewrite (`/(.*) → /index.html`) before ever reaching your
   Express server. Your sitemap route existed in code but was returning your
   homepage HTML in production. Fixed by routing those two paths to the
   server first.

2. **`client/src/components/SEO.tsx`** (new) — a shared component (via
   `react-helmet-async`) that renders a unique `<title>`, meta description,
   canonical URL, Open Graph, and Twitter tags per route.

3. **Every page** (`Index`, `About`, `GreenTowns`, `Contact`, `Donate`,
   `Blog`, `ProductDetail`) now renders `<SEO>` with route-specific content.
   `ProductDetail` also passes per-product JSON-LD (name, price, image,
   availability) through the same component instead of a separate inline
   `<script>`.

4. **`scripts/prerender.mjs`** (new) + `postbuild` script in `package.json`
   — after every build, this starts your built server locally, fetches your
   live product list, and uses a headless browser to visit every route
   (home, about, green-towns, contact, donate, blog, and every
   `/products/:id`), waits for it to fully render, and saves the resulting
   HTML as a static file (e.g. `dist/public/about/index.html`). Vercel
   serves static files before applying rewrites, so each route now serves
   real, pre-rendered content directly — no JavaScript execution required
   to see it. This is the actual fix for the "empty `<div id="root">`"
   problem non-JS crawlers (GPTBot, ClaudeBot, PerplexityBot) hit.

## Important — I could not fully test this end-to-end

I built and validated everything I could without your credentials:
TypeScript compiles clean, `vite build` succeeds, the prerender script's
syntax and logic are sound. But I don't have your `DATABASE_URL` /
`SUPABASE_URL` / `SUPABASE_ANON_KEY`, so I could not actually boot your
server or run the prerender crawl against real data — the server throws
immediately without those. **Run `npm run build` yourself locally (with
your `.env` in place) or watch the first Vercel build log closely** to
confirm the prerender step completes and check for any `[prerender] FAILED
<route>` lines.

Also: make sure `DATABASE_URL`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and
`SUPABASE_SERVICE_ROLE_KEY` are set as environment variables for the
**Build** step in Vercel (Project Settings → Environment Variables), not
just runtime — the prerender script needs the database reachable while
building, not just when serving requests.

## What's left that only you can do

- **Google Search Console**: verify the domain, submit
  `https://littleforest.co.ke/sitemap.xml`, and use URL Inspection to
  confirm Google is now indexing real content on a few product pages.
- **Google Business Profile**: set one up for Bomet — this drives local
  "tree nursery near me" visibility more than on-site SEO does.
- **Canonical domain**: confirm DNS/hosting forces `https://` and picks one
  of `littleforest.co.ke` / `www.littleforest.co.ke` consistently (redirect
  the other), so authority isn't split.
- Re-run the build once, then spot-check a handful of prerendered pages in
  a browser with JS disabled (or `curl` the URL) to confirm real content is
  there before relying on it.
